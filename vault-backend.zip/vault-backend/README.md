# Vault Backend — Setup & Deploy

## Local testing (2 min)
```bash
npm install
node server.js
# Open http://localhost:3000
```

## Deploy to Railway (5 min)

1. Push this folder to a GitHub repo:
   ```bash
   git init
   git add .
   git commit -m "Vault backend"
   # Create a repo on github.com, then:
   git remote add origin https://github.com/YOUR_USERNAME/vault-backend.git
   git push -u origin main
   ```

2. Go to railway.app → New Project → Deploy from GitHub repo → select vault-backend

3. In Railway dashboard → your service → Variables → Add these:
   ```
   PLAID_CLIENT_ID=69caa7587819c8000da51049
   PLAID_SECRET=12c30a773261d3d41831d00941a166
   PLAID_ENV=sandbox
   PORT=3000
   ```

4. Railway gives you a URL like `https://vault-backend-production.up.railway.app`

5. Update your Vault PWA: open index.html and set the API variable to your Railway URL.

## When ready for real banks
- In Plaid dashboard → switch from Sandbox to Development/Production
- Update PLAID_ENV=production and PLAID_SECRET to your production secret

## Endpoints
- POST /api/create-link-token — starts Plaid Link flow
- POST /api/exchange-token — saves access token after user connects bank
- GET  /api/accounts — all connected account balances
- GET  /api/transactions — last 30 days of transactions
- GET  /api/investments — investment holdings
- GET  /api/liabilities — credit cards, loans, mortgages
- GET  /api/net-worth — calculated net worth
